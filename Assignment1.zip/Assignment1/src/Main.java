public static void main(String[] args) {
    Fibonacci fibonacci = new Fibonacci();
    // fast
    fibonacci.analysisOutput(1);
    // slow
    fibonacci.analysisOutput(0);
    // tail
//    fibonacci.analysisOutput(2);
}
