
public class Main {
    public static void main() {
        Calculator calculator = new Calculator();
        };
        }